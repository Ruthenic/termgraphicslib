just include canvas.py in your project and install the requirements in the requirements.txt, all of the other stuff is for the example raycaster (that doesn't currently work)
as always, docs coming Soon:tm:
