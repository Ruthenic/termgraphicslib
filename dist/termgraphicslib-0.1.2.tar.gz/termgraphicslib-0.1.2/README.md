# termgraphicslib
draw epic triangles in terminal

## Raycaster
feel free to base your project off of the provided example raycaster (raycaster.py)
